const navBtns = document.querySelectorAll(".navbtn");
const views = {
  schedule: document.getElementById("view-schedule"),
  swipe: document.getElementById("view-swipe"),
  dash: document.getElementById("view-dash"),
};

function setView(name) {
  Object.keys(views).forEach((k) => (views[k].style.display = k === name ? "" : "none"));
  navBtns.forEach((b) => b.classList.toggle("active", b.dataset.view === name));
  if (name === "schedule") loadSchedule();
  if (name === "swipe") loadSwipeCandidate();
  if (name === "dash") loadDashboard();
}

navBtns.forEach((b) => b.addEventListener("click", () => setView(b.dataset.view)));

async function loadSchedule() {
  const res = await fetch("/api/schedule");
  const data = await res.json();
  const container = views.schedule;
  container.innerHTML = "";

  data.schedule.forEach(({ court, slots }) => {
    const wrap = document.createElement("div");
    const grid = document.createElement("div");
    grid.className = "grid";
    grid.appendChild(el("div", ""));
    slots.forEach((s) => grid.appendChild(el("div", s.time, "hdr")));
    grid.appendChild(el("div", court.name, "rowlabel"));
    slots.forEach((s) => {
      if (s.status === "booked") {
        const label = s.type === "training" ? "Μάθημα" : "Παιχνίδι";
        grid.appendChild(el("div", label, `slot booked ${s.type}`));
      } else {
        const cell = el("div", "Κενό", "slot gap");
        cell.addEventListener("click", () => showGapDetail(s.gapId));
        grid.appendChild(cell);
      }
    });
    wrap.appendChild(grid);
    container.appendChild(wrap);
  });

  const detail = el("div", "", "gapdetail");
  detail.id = "gap-detail";
  container.appendChild(detail);
}

async function showGapDetail(gapId) {
  const res = await fetch(`/api/gaps/${encodeURIComponent(gapId)}/suggestions`);
  const data = await res.json();
  const box = document.getElementById("gap-detail");
  box.innerHTML = "";
  const title = el(
    "p",
    data.targetLevel
      ? `Προτεινόμενοι παίκτες επιπέδου ~${data.targetLevel.toFixed(1)}`
      : "Προτεινόμενοι παίκτες (χωρίς συγκεκριμένη ζώνη επιπέδου γύρω από αυτή την ώρα)",
    "sub"
  );
  box.appendChild(title);
  data.suggestions.forEach((p) => {
    const row = el("div", "", "player");
    row.innerHTML = `<span>${p.name}</span><span style="color:var(--text-muted);">Επίπεδο ${p.level}</span>`;
    box.appendChild(row);
  });
  box.style.display = "block";
}

async function loadSwipeCandidate() {
  const res = await fetch("/api/swipe/next?playerId=p6");
  const data = await res.json();
  const container = views.swipe;
  container.innerHTML = "";
  if (!data.candidate) {
    container.appendChild(el("p", "Δεν υπάρχουν άλλοι υποψήφιοι αυτή τη στιγμή.", "sub"));
    return;
  }
  const card = document.createElement("div");
  card.className = "card";
  const initials = data.candidate.name
    .split(" ")
    .map((w) => w[0])
    .join("");
  card.innerHTML = `
    <div class="avatar">${initials}</div>
    <p style="font-weight:500; font-size:16px; margin:0;">${data.candidate.name}</p>
    <p class="sub" style="margin:4px 0 0;">Επίπεδο ${data.candidate.level}</p>
  `;
  container.appendChild(card);

  const actions = document.createElement("div");
  actions.className = "swipe-actions";
  const pass = el("button", "✕", "round");
  const like = el("button", "♥", "round");
  actions.appendChild(pass);
  actions.appendChild(like);
  container.appendChild(actions);

  const msg = el("p", "Match! Ανοίγει chat για να κλείσετε γήπεδο μαζί.", "msg");
  container.appendChild(msg);

  async function doSwipe(liked) {
    const res = await fetch("/api/swipe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fromId: "p6", toId: data.candidate.id, liked }),
    });
    const result = await res.json();
    if (result.matched) {
      msg.style.display = "block";
      setTimeout(loadSwipeCandidate, 1200);
    } else {
      loadSwipeCandidate();
    }
  }

  pass.addEventListener("click", () => doSwipe(false));
  like.addEventListener("click", () => doSwipe(true));
}

async function loadDashboard() {
  const res = await fetch("/api/dashboard");
  const data = await res.json();
  const container = views.dash;
  container.innerHTML = "";
  const metrics = document.createElement("div");
  metrics.className = "metrics";
  metrics.appendChild(metric("Σημερινή πληρότητα", `${data.occupancyPct}%`));
  metrics.appendChild(metric("Κενά σήμερα", `${data.gapSlots}/${data.totalSlots}`));
  metrics.appendChild(metric("Μαθήματα vs παιχνίδια", `${data.trainingPct}% / ${data.gamePct}%`));
  container.appendChild(metrics);
}

function metric(label, value) {
  const box = el("div", "", "metric");
  box.innerHTML = `<p>${label}</p><p>${value}</p>`;
  return box;
}

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  if (className) node.className = className;
  return node;
}

setView("schedule");
