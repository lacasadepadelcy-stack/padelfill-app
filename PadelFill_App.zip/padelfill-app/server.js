// server.js
//
// Σκόπιμα γραμμένο χωρίς εξωτερικά dependencies (μόνο builtin Node modules)
// ώστε να τρέχει παντού με ένα "node server.js", χωρίς npm install.
// Ένας developer μπορεί αργότερα να το μεταφέρει εύκολα σε Express/Fastify
// αν χρειαστεί — η λογική (matching.js / playtomicClient.js) δεν αλλάζει.

const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const matching = require("./src/matching");
const swipeModule = require("./src/swipe");

const PUBLIC_DIR = path.join(__dirname, "public");
const MIME = { ".html": "text/html", ".js": "application/javascript", ".css": "text/css" };

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(body);
}

function serveStatic(req, res, pathname) {
  const filePath = pathname === "/" ? "/index.html" : pathname;
  const fullPath = path.join(PUBLIC_DIR, filePath);
  if (!fullPath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  fs.readFile(fullPath, (err, content) => {
    if (err) {
      res.writeHead(404);
      return res.end("Not found");
    }
    const ext = path.extname(fullPath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(content);
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const { pathname, searchParams } = url;

  try {
    if (pathname === "/api/schedule" && req.method === "GET") {
      const date = searchParams.get("date") || todayISO();
      return sendJSON(res, 200, { date, schedule: matching.buildSchedule(date) });
    }

    const gapMatch = pathname.match(/^\/api\/gaps\/([^/]+)\/suggestions$/);
    if (gapMatch && req.method === "GET") {
      const date = searchParams.get("date") || todayISO();
      const gapId = decodeURIComponent(gapMatch[1]);
      return sendJSON(res, 200, matching.suggestPlayersForGap(gapId, date));
    }

    if (pathname === "/api/dashboard" && req.method === "GET") {
      const date = searchParams.get("date") || todayISO();
      return sendJSON(res, 200, matching.buildDashboard(date));
    }

    if (pathname === "/api/swipe/next" && req.method === "GET") {
      const forId = searchParams.get("playerId") || "p6";
      return sendJSON(res, 200, { candidate: swipeModule.getNextCandidate(forId) });
    }

    if (pathname === "/api/swipe" && req.method === "POST") {
      const body = await readBody(req);
      const { fromId, toId, liked } = body;
      if (!fromId || !toId || typeof liked !== "boolean") {
        return sendJSON(res, 400, { error: "fromId, toId, liked (boolean) απαιτούνται" });
      }
      return sendJSON(res, 200, swipeModule.swipe(fromId, toId, liked));
    }

    if (pathname.startsWith("/api/")) {
      return sendJSON(res, 404, { error: "Άγνωστο endpoint" });
    }

    return serveStatic(req, res, pathname);
  } catch (err) {
    return sendJSON(res, 500, { error: String(err) });
  }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`PadelFill Phase 1 prototype: http://localhost:${PORT}`);
});
