# PadelFill — Phase 1 prototype

Λειτουργικό πρωτότυπο (όχι απλό mockup) για το PadelFill: εντοπίζει κενά στο
πρόγραμμα γηπέδων και προτείνει παίκτες ίδιου επιπέδου να τα γεμίσουν.
Περιλαμβάνει επίσης πρώτη υλοποίηση του "Swipe to play" (Φάση 3).

Οι κρατήσεις/παίκτες προς το παρόν είναι **mock δεδομένα** (βλ.
`src/playtomicClient.js`) — δεν υπάρχει ακόμα σύνδεση με το πραγματικό
Playtomic API key.

## Πώς τρέχει τοπικά

Δεν έχει εξωτερικά dependencies (μόνο builtin Node.js) — αρκεί:

```
npm start
```

(ή απλά `node server.js`). Μετά ανοίγεις `http://localhost:3000` στον browser.
Χρειάζεται μόνο Node.js εγκατεστημένο στον υπολογιστή.

## Δομή κώδικα

- `src/playtomicClient.js` — όλα τα δεδομένα που κανονικά θα έρχονταν από το
  Playtomic (γήπεδα, ώρες, κρατήσεις, παίκτες με επίπεδο). **Αυτό είναι το
  μοναδικό αρχείο που χρειάζεται αλλαγή** για να συνδεθεί η εφαρμογή με το
  πραγματικό Playtomic API — το "σχήμα" των δεδομένων πρέπει να μείνει ίδιο.
- `src/matching.js` — η λογική: εντοπισμός κενών (gap detection), πρόταση
  παικτών ίδιου επιπέδου, στατιστικά για το dashboard.
- `src/swipe.js` — απλή, in-memory λογική για like/pass/match (Φάση 3).
- `server.js` — Express API (`/api/schedule`, `/api/gaps/:id/suggestions`,
  `/api/dashboard`, `/api/swipe/*`).
- `public/` — απλό frontend (χωρίς framework) που καλεί το API.

## Τι λείπει για production (χρειάζεται developer)

1. **Πραγματική σύνδεση με Playtomic API** — OAuth login πελατών + άντληση
   πραγματικών κρατήσεων/επιπέδου (βλ. σημειώσεις μέσα στο
   `playtomicClient.js`).
2. **Βάση δεδομένων** — τώρα όλα είναι σε μνήμη/στατικά αρχεία· χρειάζεται
   πραγματική βάση (π.χ. Postgres) για ιστορικό, προφίλ, likes/matches.
3. **Ειδοποιήσεις** (push/SMS/email) όταν βρεθεί ταίρι για ένα κενό.
4. **Mobile app** — αυτό το πρωτότυπο είναι web· χρειάζεται React
   Native/Flutter wrapper (ή PWA) για iOS/Android.
5. **Auth/ασφάλεια** — κανένα endpoint δεν έχει authentication ακόμα.
6. **Multi-tenant** — προς το παρόν χτισμένο για ένα club· η αναδιαμόρφωση
   για πολλά club (ξεχωριστό Playtomic API key ανά club) γίνεται στη Φάση 4,
   όπως περιγράφεται στο έγγραφο απαιτήσεων.

Δες `PadelFill_Requirements.docx` για το πλήρες πλάνο και τις αποφάσεις.
