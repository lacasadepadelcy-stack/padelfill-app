// swipe.js
//
// Απλή, in-memory υλοποίηση του "Swipe to Play" (Φάση 3 στο έγγραφο
// απαιτήσεων). Δεν είναι συνδεδεμένο με πραγματική βάση δεδομένων — είναι
// μόνο για να δείξει τη λογική (like/pass -> match όταν είναι αμοιβαίο).

const playtomic = require("./playtomicClient");

// likes[fromId] = Set από ids που έχει κάνει like
const likes = {};

function getNextCandidate(forPlayerId) {
  const players = playtomic.getPlayers();
  const me = players.find((p) => p.id === forPlayerId);
  const seen = likes[forPlayerId] || new Set();
  const pool = players.filter(
    (p) =>
      p.id !== forPlayerId &&
      !seen.has(p.id) &&
      (!me || Math.abs(p.level - me.level) <= 0.5)
  );
  return pool[0] || null;
}

function swipe(fromId, toId, liked) {
  if (!likes[fromId]) likes[fromId] = new Set();
  if (liked) {
    likes[fromId].add(toId);
  }

  // Mock αμοιβαιότητα: για το demo, θεωρούμε ότι ο άλλος παίκτης έχει ήδη
  // κάνει like σε 'p1' ώστε να μπορεί κανείς να δει ένα πραγματικό match.
  const reciprocal = likes[toId] && likes[toId].has(fromId);
  const demoMatch = liked && toId === "p1";

  return { matched: Boolean(liked && (reciprocal || demoMatch)) };
}

module.exports = { getNextCandidate, swipe };
