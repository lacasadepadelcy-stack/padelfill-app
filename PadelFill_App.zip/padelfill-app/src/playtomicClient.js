// playtomicClient.js
//
// Αυτό το αρχείο "μιμείται" το Playtomic API με στατικά (mock) δεδομένα, ώστε
// όλη η υπόλοιπη εφαρμογή (gap detection, matching, dashboard) να μπορεί να
// αναπτυχθεί και να δοκιμαστεί χωρίς πραγματικό API key.
//
// ΓΙΑ ΣΥΝΔΕΣΗ ΜΕ ΤΟ ΠΡΑΓΜΑΤΙΚΟ PLAYTOMIC API:
//   1. Πάρτε API key / OAuth credentials από το Playtomic Business.
//   2. Αντικαταστήστε τις συναρτήσεις παρακάτω με πραγματικά HTTP calls
//      (π.χ. με fetch/axios) προς τα endpoints του Playtomic.
//   3. Το "σχήμα" (shape) των δεδομένων που επιστρέφουν οι συναρτήσεις
//      πρέπει να παραμείνει ίδιο, ώστε να μη χρειαστεί αλλαγή στον
//      υπόλοιπο κώδικα (matching.js, server.js).
//
// Αυτό είναι το βασικό "σημείο σύνδεσης" (integration point) με το πραγματικό Playtomic.

const COURTS = [
  { id: "court-1", name: "Γήπεδο 1" },
  { id: "court-2", name: "Γήπεδο 2" },
];

const HOURS = ["17:00", "18:00", "19:00", "20:00", "21:00", "22:00"];

// Mock παίκτες με επίπεδο (στο πραγματικό Playtomic αυτό θα έρχεται από το
// προφίλ / ιστορικό αγώνων του κάθε παίκτη).
const PLAYERS = [
  { id: "p1", name: "Μαρία Π.", level: 3.5, phone: "99xxxxx1" },
  { id: "p2", name: "Γιώργος Σ.", level: 3.5, phone: "99xxxxx2" },
  { id: "p3", name: "Ελένη Τ.", level: 4.0, phone: "99xxxxx3" },
  { id: "p4", name: "Ανδρέας Κ.", level: 2.5, phone: "99xxxxx4" },
  { id: "p5", name: "Δήμητρα Λ.", level: 3.0, phone: "99xxxxx5" },
  { id: "p6", name: "Νίκος Κ.", level: 3.5, phone: "99xxxxx6" },
  { id: "p7", name: "Κατερίνα Μ.", level: 3.0, phone: "99xxxxx7" },
  { id: "p8", name: "Παύλος Ν.", level: 4.0, phone: "99xxxxx8" },
];

// Mock κρατήσεις για "σήμερα". type: "game" (παιχνίδι) ή "training" (μάθημα).
// Οι ώρες που ΔΕΝ εμφανίζονται εδώ για κάποιο γήπεδο θεωρούνται κενές (gap).
const BOOKINGS = [
  { court: "court-1", time: "17:00", type: "game", players: ["p1", "p2"] },
  { court: "court-1", time: "18:00", type: "training", players: ["p4"] },
  { court: "court-1", time: "20:00", type: "game", players: ["p6", "p7"] },
  { court: "court-1", time: "22:00", type: "game", players: ["p3", "p8"] },
  { court: "court-2", time: "17:00", type: "training", players: ["p5"] },
  { court: "court-2", time: "19:00", type: "game", players: ["p2", "p3"] },
  { court: "court-2", time: "21:00", type: "game", players: ["p4", "p5"] },
];

function getCourts() {
  return COURTS;
}

function getHours() {
  return HOURS;
}

function getPlayers() {
  return PLAYERS;
}

function getBookingsForDate(_date) {
  // Στο πραγματικό API: GET /bookings?date=... ανά club.
  return BOOKINGS;
}

module.exports = { getCourts, getHours, getPlayers, getBookingsForDate };
